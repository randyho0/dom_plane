1. 什么时候用that,什么时候用this

分析问题:
面向Player类进行开发

this预期:指向我们Player对象

谁调用函数，this就指向谁

当我们去到回调函数时候
函数作用域发生了改变

A.prototype.init=function(){
	this指向A对象
	this.age = 18
	let that = this;
	let box = this.box
	box.addEventListener("type",function(){
		当前this对象不再指向A对象
		
		如果要修改A对象的age属性
		that.age = 20;
	})
	
}

2. 实例化子弹类的时机
如果一开始，在game的init方法里面，实例化子弹类
我们无法获取到，实例玩家飞机的坐标

解决方法,子弹类的默认位置，单独设置，与飞机坐标一致。

3. 碰撞检测

一：采用最小最大顶点法描述AABB包围盒

上图中使用了最小最大顶点法来描述包围盒信息，由于是在屏幕坐标系中，y轴是向下延伸的，所以只需要保留矩形中坐标的最小值和最大值即可，即矩形的左上角和右下角的顶点，其他的点都在这两个点范围内。

在这种情况下要判断两个矩形是否碰撞只需要比较两个矩形顶点的坐标即可，
假设矩形 A用(x1, y1)表示左上角，(x2, y2)表示右下角，
矩形B用(x3, y3)表示左上角，(x4, y4)表示右下角，
则满足下列条件则表示没有碰撞，反之则碰撞。

没碰撞：x1>x4 或者x2<x3。

没碰撞：y1>y4 或者y2<y3。

所以，在程序中做二维游戏的AABB碰撞检测时，只需验证物体A与物体B是否满足如下条件：

（1）物体A的Y轴方向最小值大于物体B的Y轴方向最大值；
					
（2）物体A的X轴方向最小值大于物体B的X轴方向最大值；

（3）物体B的Y轴方向最小值大于物体A的Y轴方向最大值；

（4）物体B的X轴方向最小值大于物体A的X轴方向最大值；

若满足上述条件，则证明物体A与物体B并未发生重合，反之，则证明物体A与物体B重合

function hitTest(source, target) { 
	/* 源物体和目标物体都包含 x, y 以及 width, height */
	return !(
	((source.y + source.r) < (target.y)) 
	|| 
	(source.y > (target.y + target.r)) 
	|| 
	((source.x + source.r) < target.x) 
	|| 
	(source.x > (target.x + target.r))
	);
}

4. 做这么项目的意义

1. 大家收获了面向对象的开发模式
   减少了全局变量的产生，
   大家代码质量，从"杂乱无章"到 "稍微整洁"

2. 编写逻辑代码之前

先把需求列出来，
针对需求，细化功能点

培养大家的条理性
流程图分析---编写成逻辑代码

调试代码习惯----debugger/console.log 大家后续也是会多用的

资料的查阅(帮助大家解决问题手段之一) ---- 结合自身自考----开发的过程

没有概念-如何查资料--使用--类似的关键词

第一次接触新事物，都会有蒙圈的过程，随着学习的沉淀，最终认清
事物的本质

除了收获知识点以外，更重要的是，大家从小白的无从下手，到熟练的开发习惯

结合项目

没有面向对象概念 
---- 前置知识点（创建对象的方法--工厂函数，构造函数，原型模式，原型+构造函数）
---- 资料来源 "红宝石书"--第6章第3节
---- 原型，原型对象，实例的关系（前置知识，js基本数据类型与引用类型的区别）

飞机的及时坐标 如何 告诉给 子弹类
(快递)                  (收货人)
快递员 与 收货人 的故事
plane    bullet
收货人 提供了 联系方式
bullet       Bullet.prototype.setPos 
快递员 调用 收货人的联系方式 --- 拿到最新快递
plane 可以调用 Bullet.prototype.setPos(x,y); 

function setPos(x,y){
	拿到最新的坐标后，
	更新到bullet的坐标属性
	this.pos_x = x;
	这个this是挂在 Bullet.prototype
}

弯路---属性的所在地
	Bullet.prototype.setPos(x,y)
	最新的坐标是在Bullet.prorotype
"优化过程"-一开始，设置 子弹的起始坐标----
		this.pos_x = (Stage.width - this.bullet.width) / 2;
这就是bug所在的地方----靠理论来支撑
		
		bullet = new Bullet()----(new 操作符具体做了什么)
		
		bullet.pos_x = x;
		
		Bullet.prototype.pos_x = 最新的坐标值

当实例化对象 与 原型对象属性，同名时，
JS选择实例化对象的同名属性，屏蔽，原型对象上的属性 (就近原则)

例子： 
function Boy(){}
Boy.prototype.money = 100;

var boy = new Boy();
boy.money = 10;

console.log(boy.money)  

解决方法
实例化对象
bullet里面，不要写pos_x属性，让他通过"原型链"去找

Bullet.prototype.setPos = function(pos_x,pos_y){
	兼容处理;
	this.pos_x = pos_x || (Stage.width - this.width) /2;
}








